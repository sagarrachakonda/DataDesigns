package com.datadesign.datadesign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatadesignApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatadesignApplication.class, args);
	}

}
